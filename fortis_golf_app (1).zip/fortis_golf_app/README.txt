Fortis Golf Web App

Open index.html on a phone browser. Data is stored locally in the browser using localStorage.

Version: Fortis 4-player + individual matchup handicap engine.
Seed matchups: Paul gives Davie 7; Davie gives Sam 5; Davie gives Adam 7; Warren gives Paul 2.
